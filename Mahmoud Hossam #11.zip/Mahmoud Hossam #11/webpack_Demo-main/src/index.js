import hello from "./hello world"
hello()





import "./style.css"



import "./component/header/header"
import"./component/cover/cover"

import"./component/bio/bio"


import"./assets/city.png"






// // //
// // /* 
// // this is a big comment









// //  */