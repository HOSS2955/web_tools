let section= document.getElementsByClassName("hero01")[0]


 const element = document.createElement("h1");
element.style.padding="100px"
element.innerHTML = "This Is A Great Website!!";
section.prepend(element)



// this is a comment
